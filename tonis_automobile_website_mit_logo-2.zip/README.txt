TONI'S AUTOMOBILE – Website-Demo

START:
1. ZIP entpacken.
2. index.html im Browser öffnen.

ANPASSEN:
- In index.html im Script WHATSAPP_NUMBER auf Ihre echte WhatsApp-Nummer ändern.
  Format: Ländervorwahl + Nummer, nur Ziffern, z. B. 491761234567.
- Die drei Beispiel-Fahrzeuge in der Verwaltung entfernen und eigene Fahrzeuge hinzufügen.
- Vor Veröffentlichung Impressum und Datenschutzerklärung ergänzen.

WICHTIG:
Diese Version ist ein klickbarer Frontend-Prototyp. Die Fahrzeugverwaltung speichert
Daten lokal im jeweiligen Browser (localStorage). Besucher auf anderen Geräten sehen
nicht automatisch dieselben Fahrzeuge; hinzugefügte Autos werden nicht zentral
gespeichert. Für eine echte öffentliche Firmenwebsite mit gemeinsamer Verwaltung
braucht es Hosting und eine zentrale Datenbank/CMS sowie einen geschützten Admin-Zugang.

LOGO:
Das bereitgestellte Firmenlogo liegt als tonis-logo.jpg bei und wird im Kopfbereich der Website angezeigt.
